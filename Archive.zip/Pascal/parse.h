#ifndef _PARSE_H_
#define _PARSE_H_
#include "global.h"
TreeNode * parse(void);

#endif
